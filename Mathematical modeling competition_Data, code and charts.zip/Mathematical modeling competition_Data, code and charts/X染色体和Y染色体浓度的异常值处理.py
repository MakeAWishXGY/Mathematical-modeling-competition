import pandas as pd
# 要进行Y染色体浓度处理时 把X换为Y即可
def remove(file_path):
    # 表名
    target_sheet_name = '女胎检测数据'
    try:
        # 读取文件
        excel_file = pd.ExcelFile(file_path)

        # 尝试获取工作表中的数据
        try:
            df = excel_file.parse(target_sheet_name)
        except KeyError:
            print(f"文件中不存在名为 '{target_sheet_name}' 的工作表，无法进行处理。")
            return

        # 检查 X 染色体浓度列是否存在
        if 'X染色体浓度' not in df.columns:
            print(f"工作表 '{target_sheet_name}' 中不存在 'X染色体浓度' 列，无法进行异常值处理。")
            return

        # 检查序号列是否存在
        if '序号' not in df.columns:
            print(f"工作表 '{target_sheet_name}' 中不存在 '序号' 列，无法准确输出删除数据的序号信息。")
            return

        # 记录原始数据的数量
        original_count = df.shape[0]

        # 计算箱线图的上下四分位数和四分位距
        Q1 = df['X染色体浓度'].quantile(0.25)
        Q3 = df['X染色体浓度'].quantile(0.75)
        IQR = Q3 - Q1

        # 计算异常值的上下边界
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        # 筛选出异常值的数据并记录序号
        outliers_df = df[(df['X染色体浓度'] < lower_bound) | (df['X染色体浓度'] > upper_bound)]

        # 筛选出非异常值的数据
        df = df[(df['X染色体浓度'] >= lower_bound) & (df['X染色体浓度'] <= upper_bound)]

        # 记录处理后数据的数量
        processed_count = df.shape[0]

        if original_count == processed_count:
            print(f"工作表 '{target_sheet_name}' 中没有 X 染色体浓度的异常值，未进行删除操作。")
        else:
            print(
                f"工作表 '{target_sheet_name}' 成功删除 X 染色体浓度的异常值，共删除 {original_count - processed_count} 条数据。")
            print(f"删除的数据对应的序号为：{outliers_df['序号'].tolist()}")

        # 将结果写回 Excel 文件
        with pd.ExcelWriter(file_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
            df.to_excel(writer, sheet_name=target_sheet_name, index=False)

    except Exception as e:
        print(f"处理文件过程中出现未知错误: {e}")


# 调用函数并传入文件路径
file_path = '附件.xlsx'
remove(file_path)