clear all 		//清空内存中的数据
set more off 	//关闭more选项，一次性输出全部结果，这两行代码一般都写在do file最开头。
*第一步： 设置本次项目数据所在文件夹路径（非常重要!）
pwd				//查看目前的工作路径	
cd "D:\比赛\数模比赛\二题"
import excel "D:\比赛\数模比赛\二题\第二问误差数据处理.xlsx", sheet("无标题8") firstrow
* 1. 按孕妇分组并按孕周排序（确保时间顺序）
sort 孕妇代码 检测孕周
* 2. 标记Y染色体浓度>0.04的观测
gen Y004 = (Y染色体浓度随机 > 0.04)
* 3. 判断每个孕妇是否存在Y>0.04的记录（兼容所有Stata版本的写法）
bysort 孕妇代码: gen has_Y004 = 0  // 初始化为0（无符合条件记录）
bysort 孕妇代码: replace has_Y004 = 1 if sum(Y004) > 0  // 若有至少1条符合条件，标记为1
* 4. 标记第一次Y>0.04的观测（仅对有符合条件的孕妇）
bysort 孕妇代码: gen first_Y004 = 0  // 初始化为0
bysort 孕妇代码: replace first_Y004 = 1 if Y004 == 1 & sum(Y004) == 1  // 累积到第1条符合条件的记录
* 5. 对无Y>0.04的孕妇，标记其第一条记录（作为保留对象）
bysort 孕妇代码: gen is_first_record = (_n == 1)  // 组内第一条记录
* 6. 定义需要保留的观测
gen keep = 0  // 0=不保留，1=保留
// 情况1：有Y>0.04的孕妇，保留第一次达标的记录
replace keep = 1 if has_Y004 == 1 & first_Y004 == 1
// 情况2：无Y>0.04的孕妇，保留第一条记录
replace keep = 1 if has_Y004 == 0 & is_first_record == 1
* 7. 对无Y>0.04的孕妇，将其保留记录的孕周改为0
replace 检测孕周 = 0 if has_Y004 == 0 & keep == 1
* 8. 执行保留操作
keep if keep == 1
* 9. 查看处理结果（验证用）
list 孕妇代码 检测孕周 Y染色体浓度 has_Y004 in 1/10, noobs  // 显示前10条记录
count  // 显示最终保留的总记录数
drop if Y染色体浓度 > 0.04 & 检测孕周 == 0
* 按孕妇代码分组，仅当组内有2条记录时，删除第一条
bysort 孕妇代码: drop if _N == 2 & _n == 1
drop Y004 has_Y004 first_Y004 is_first_record keep
export excel using "第二问数据处理2.xlsx", firstrow(variables) replace


