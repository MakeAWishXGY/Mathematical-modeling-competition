clear all 		//清空内存中的数据
set more off 	//关闭more选项，一次性输出全部结果，这两行代码一般都写在do file最开头。
*第一步： 设置本次项目数据所在文件夹路径（非常重要!）
pwd				//查看目前的工作路径	
cd "D:\比赛\数模比赛\一题"
import excel "D:\比赛\数模比赛\题目\2025数模国赛题目(1)\C题\附件.xlsx", sheet("男胎检测数据") firstrow clear
sum, detail
save "data.dta", replace
***转化周数
* 提取周数部分
gen week = real(substr(检测孕周, 1, strpos(检测孕周, "w") - 1))

* 提取天数部分
gen day = 0  // 先初始化天数为0
replace day = real(substr(检测孕周, strpos(检测孕周, "+") + 1, .)) if strpos(检测孕周, "+") > 0

* 计算小数形式的孕周（周数 + 天数/7）
gen 检测孕周_小数 = week + day / 7

* 删除检测孕周<10周 或 检测孕周>25周的观测值
drop if 检测孕周_小数 < 10 | 检测孕周_小数 > 25

export excel using "处理孕周值.xlsx", firstrow(variables) replace

histogram Y染色体浓度 , normal title("Y染色体浓度正态分布图")

****妊娠方式
import excel "D:\比赛\数模比赛\一题\处理孕周值+非正态分布剔除.xlsx", sheet("Sheet1") firstrow clear
* 按"孕妇代码"排序，并仅保留每组第1条记录
bysort 孕妇代码: keep if _n == 1  

* 查看每个孕妇代码对应的IVF状态
list 孕妇代码 IVF妊娠
keep 孕妇代码 IVF妊娠
save "bornway.dta", replace

****求均值
import excel "D:\比赛\数模比赛\一题\处理孕周值+非正态分布剔除.xlsx", sheet("Sheet1") firstrow clear
* 步骤1：创建新的数值变量（初始化为缺失值）
gen 怀孕次数_数字 = .

* 步骤2：处理特殊值"≥3"，转换为数字3
replace 怀孕次数_数字 = 3 if 怀孕次数 == "≥3"

* 步骤3：处理其他数值字符（如"1"、"2"），转换为对应的数字
replace 怀孕次数_数字 = real(怀孕次数) if 怀孕次数_数字 == .  // 仅处理未被上一步覆盖的观测

* 步骤4：查看转换结果，确认是否正确
list 怀孕次数 怀孕次数_数字, clean noobs
drop 怀孕次数
rename 怀孕次数_数字 怀孕次数

drop 检测孕周
rename 检测孕周_小数 检测孕周

collapse (mean)  年龄 孕妇BMI Y染色体浓度  GC含量 怀孕次数 生产次数 , by(孕妇代码 检测孕周)

save "mean.dta", replace

merge m:1 孕妇代码 using  "bornway.dta"
drop _merge
export excel using "数据预处理.xlsx", firstrow(variables) replace

*****第二问处理
* 1. 按孕妇分组并按孕周排序（确保时间顺序）
sort 孕妇代码 检测孕周

* 2. 标记Y染色体浓度>0.04的观测
gen Y004 = (Y染色体浓度 > 0.04)

* 3. 判断每个孕妇是否存在Y>0.04的记录（兼容所有Stata版本的写法）
bysort 孕妇代码: gen has_Y004 = 0  // 初始化为0（无符合条件记录）
bysort 孕妇代码: replace has_Y004 = 1 if sum(Y004) > 0  // 若有至少1条符合条件，标记为1

* 4. 标记第一次Y>0.04的观测（仅对有符合条件的孕妇）
bysort 孕妇代码: gen first_Y004 = 0  // 初始化为0
bysort 孕妇代码: replace first_Y004 = 1 if Y004 == 1 & sum(Y004) == 1  // 累积到第1条符合条件的记录

* 5. 对无Y>0.04的孕妇，标记其第一条记录（作为保留对象）
bysort 孕妇代码: gen is_first_record = (_n == 1)  // 组内第一条记录

* 6. 定义需要保留的观测
gen keep = 0  // 0=不保留，1=保留
// 情况1：有Y>0.04的孕妇，保留第一次达标的记录
replace keep = 1 if has_Y004 == 1 & first_Y004 == 1
// 情况2：无Y>0.04的孕妇，保留第一条记录
replace keep = 1 if has_Y004 == 0 & is_first_record == 1

* 7. 对无Y>0.04的孕妇，将其保留记录的孕周改为0
replace 检测孕周 = 0 if has_Y004 == 0 & keep == 1

* 8. 执行保留操作
keep if keep == 1

* 9. 查看处理结果（验证用）
list 孕妇代码 检测孕周 Y染色体浓度 has_Y004 in 1/10, noobs  // 显示前10条记录
count  // 显示最终保留的总记录数
drop if Y染色体浓度 > 0.04 & 检测孕周 == 0

* 按孕妇代码分组，仅当组内有2条记录时，删除第一条
bysort 孕妇代码: drop if _N == 2 & _n == 1

drop Y004 has_Y004 first_Y004 is_first_record keep
export excel using "第二问数据处理.xlsx", firstrow(variables) replace

import excel "D:\比赛\数模比赛\题目\2025数模国赛题目(1)\C题\附件.xlsx", sheet("男胎检测数据") firstrow clear
* 按"孕妇代码"分组，初始化标记变量
bysort 孕妇代码: gen has_diff_dates = 0  

* 若孕妇有≥2条记录，且首条与末条末次月经不同，则标记为"存在差异"
bysort 孕妇代码: replace has_diff_dates = 1 if _N > 1 & (末次月经[1] != 末次月经[_N])
keep if has_diff_dates == 1















