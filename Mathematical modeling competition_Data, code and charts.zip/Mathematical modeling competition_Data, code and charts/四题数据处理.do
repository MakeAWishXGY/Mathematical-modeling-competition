clear all 		//清空内存中的数据
set more off 	//关闭more选项，一次性输出全部结果，这两行代码一般都写在do file最开头。
*第一步： 设置本次项目数据所在文件夹路径（非常重要!）
pwd				//查看目前的工作路径	
cd "D:\比赛\数模比赛\四题"

import excel "D:\比赛\数模比赛\四题\附件(1).xlsx", sheet("女胎检测数据") firstrow clear
sort 孕妇代码
by 孕妇代码: keep if _n == 1
save "all.dta", replace

import excel "D:\比赛\数模比赛\四题\附件(1).xlsx", sheet("女胎检测数据") firstrow clear
******孕周改成小数
* 提取周数部分
gen week = real(substr(检测孕周, 1, strpos(检测孕周, "w") - 1))
* 提取天数部分
gen day = 0  // 先初始化天数为0
replace day = real(substr(检测孕周, strpos(检测孕周, "+") + 1, .)) if strpos(检测孕周, "+") > 0
* 计算小数形式的孕周（周数 + 天数/7）
gen 检测孕周_小数 = week + day / 7

******删除检测孕周<10周 或 检测孕周>25周的观测值
drop if 检测孕周_小数 < 10 | 检测孕周_小数 > 25
drop 检测孕周
rename 检测孕周_小数 检测孕周

*****GC含量
drop if GC含量 < 0.4 | GC含量 > 0.6

******Z值
drop if 号染色体的Z值 < -3 | 号染色体的Z值 >3
drop if R < -3 | R >3
drop if 号染色体的Z值 < -3 | 号染色体的Z值 >3
drop if X染色体的Z值 < -3 | X染色体的Z值 >3
*****月经期不一致
* 按"孕妇代码"分组，初始化标记变量
bysort 孕妇代码: gen has_diff_dates = 0  
* 若孕妇有≥2条记录，且首条与末条末次月经不同，则标记为"存在差异"
bysort 孕妇代码: replace has_diff_dates = 1 if _N > 1 & (末次月经[1] != 末次月经[_N])
keep if has_diff_dates == 0

********均值
collapse (mean)  年龄 身高 体重 孕妇BMI 原始读段数 在参考基因组上比对的比例 重复读段的比例 唯一比对的读段数 GC含量 号染色体的Z值 R S X染色体的Z值 Unnamed20 Unnamed21 X染色体浓度 号染色体的GC含量 Y Z 被过滤掉读段数的比例, by(孕妇代码 检测孕周)
save "mean.dta", replace


merge m:1 孕妇代码 using "all.dta", keepusing(IVF妊娠)  // 
drop _merge Unnamed20 Unnamed21
export excel using "第四问数据.xlsx", firstrow(variables) replace
